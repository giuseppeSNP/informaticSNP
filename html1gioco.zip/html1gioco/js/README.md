# html5gametutorial
HTML5 game tutorial made for HTML.IT

# Demo
http://tizzio.github.io/html5gametutorial

# tutorial link (italian)
www.html.it/guide/html5-games-guida-alla-creazione-di-giochi/
